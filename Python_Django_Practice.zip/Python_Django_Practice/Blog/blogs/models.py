from django.db import models

class BlogPost(models.Model):
    """A blogpost class for user enter title and text."""
    title = models.CharField(max_length=1000)
    text  = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        if len(self.text) <= 50:
            """Return a string representation of the model."""
            return f"{self.title}:\n\n\t {self.text}"
        else:
            return f"{self.title}:\n\n\t {self.text[:50]}..."
