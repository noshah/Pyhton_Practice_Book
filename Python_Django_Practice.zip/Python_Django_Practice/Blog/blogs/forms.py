from django import forms

from .models import BlogPost

class BlogForm(forms.ModelForm):
    class Meta:
        model = BlogPost
        fields = ['title', 'text']
        labels = {'title': '', 'text': ''}
        widgets = {'title': forms.Textarea(attrs={'cols': 150, 'rows': 5}), 'text': forms.Textarea(attrs={'cols': 150, 'rows': 30})}